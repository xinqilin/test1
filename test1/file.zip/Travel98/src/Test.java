import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Test {
	// 台北車站
	private static final String MAIN_STATION_URL = "https://travel98.com/sight/6096";
	// 西門町
	private static final String XIMEN_URL = "https://travel98.com/sight/15335";
	
	public static void main(String[] args) throws IOException {
		// 先用Jsoup把該網頁的HTML取得，是一個Document物件，請觀察標籤關係
		Document doc = Jsoup.connect(MAIN_STATION_URL).get();

		// 取得標題
		Elements elements = doc.select("h1 > a");
		System.out.println(elements.get(0).text());

		// 取得地點敘述
		Elements elements2 = doc.select("p");
		System.out.println(elements2.get(1).text());

		// 取得地址
		Elements elements3 = doc.select(".content > div");
		System.out.println(elements3.get(1).nextSibling().toString().trim());

	}

}
